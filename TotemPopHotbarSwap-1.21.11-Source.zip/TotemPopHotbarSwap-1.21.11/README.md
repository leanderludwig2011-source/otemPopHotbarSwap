# Totem Pop Hotbar Swap (Fabric 1.21.11)

A small client-only mod. When **your own totem activates**, the mod selects the next hotbar slot containing a Totem of Undying. It searches slots cyclically from the currently selected slot (1→2→…→9→1). It **does not** move an item into the offhand and does not preselect a totem before a pop. If no totem is available in the hotbar, it does nothing.

## Build

Requires Java 21 and Gradle (Loom version 1.14). In this folder, run:

```bash
gradle build
```

After a successful build, the Minecraft-ready jar is in `build/libs/` (choose the jar without `-sources` or `-dev`). Copy it into `.minecraft/mods` and start Minecraft **1.21.11** with Fabric Loader. No Fabric API dependency is needed.

On macOS with Homebrew, Gradle can be installed with `brew install gradle`. You can alternatively open this project as a Gradle project in IntelliJ IDEA and build it there.

## Notes

- Source project, **not a compiled jar**; it has not been compiled or tested in this environment.
- This may violate multiplayer server rules. Check rules before use.
- It does not automatically equip a totem into the offhand; it changes your **main-hand hotbar selection**.
- The code detects the server's entity status 35 (totem activation), and ignores other entities.
